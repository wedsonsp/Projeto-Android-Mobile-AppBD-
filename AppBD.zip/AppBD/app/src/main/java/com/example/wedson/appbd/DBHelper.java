package com.example.wedson.appbd;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wedson on 19/12/2016.
 */

public class DBHelper {
    //Declarando atributos estaticos do tipo final que é uma constante.
    private static final String DATABASE_NAME = "bancodedados.db";
    private static final int DATABASE_VERSION = 1;
    //Nome da tabela do banco de dados.
    private static final String TABLE_NAME = "contato";

    private Context context;
    private SQLiteDatabase db;

    private SQLiteStatement insertStmt;
    private static final String INSERT = "insert into " + TABLE_NAME + " (nome, endereco, empresa) values (?,?,?)";

    public DBHelper(Context context) {
        this.context = context;
        //Classe openHelper
        OpenHelper openHelper = new OpenHelper(this.context);
        this.db = openHelper.getWritableDatabase();
        this.insertStmt = this.db.compileStatement(INSERT);
    }

    //Método Insert
    public long insert(String nome, String endereco, String empresa) {
        this.insertStmt.bindString(1, nome);
        this.insertStmt.bindString(2, endereco);
        this.insertStmt.bindString(3, empresa);

        return this.insertStmt.executeInsert();
    }

    //Método para Deletar
    public void deleteAll() {
        this.db.delete(TABLE_NAME, null, null);
    }

    //Retorna uma lista de Contatos. Pegando todas as informações gravadas no banco.
    public List<Contato> queryGetAll() {
        List<Contato> list = new ArrayList<Contato>();
        //Tratamento de erros e excessões.
        try {
            Cursor cursor = this.db.query(TABLE_NAME, new String[]{"nome", "endereco", "empresa"},
                    null, null, null, null, null, null);
            int nregistros = cursor.getCount();
            if (nregistros != 0) {
                cursor.moveToFirst();
                do {
                    //Criando um Contato.
                    Contato contato = new Contato(cursor.getString(0), cursor.getString(1), cursor.getString(2));
                    list.add(contato);
                } while (cursor.moveToNext());

                // Se o cursor não estiver vazio e não estiver fechado ele retorna a lista.
                if (cursor != null && !cursor.isClosed()) {
                    cursor.close();
                    return list;
                }
            } else {
                return null;
            }
        } catch (Exception Err) {
            return null;
        }

        return list;
    }

    //Herdando ou extendendo a classe OpenHelper para a Classe SQLiteOpenHelper.
    private static class OpenHelper extends SQLiteOpenHelper {

        //Chama o Construtor da Classe base.
        OpenHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        //Os métodos abaixo precisam ser implementados pois derivam da classe Abtsrata SQLiteOpenHelper.

        //Método onCreate que cria a tabela caso ela não exista.
        public void onCreate (SQLiteDatabase db){
            String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME +" (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, endereco TEXT, empresa TEXT);";
            db.execSQL(sql);
        }

        //Método onUpgrade Apaga e cria uma nova tabela.
        public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

    }
}
