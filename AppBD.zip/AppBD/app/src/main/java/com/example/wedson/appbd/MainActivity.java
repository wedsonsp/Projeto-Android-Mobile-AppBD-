package com.example.wedson.appbd;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DBHelper dh;
    EditText etNome, etEnd, etEmp;
    Button btInserir, btListar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.dh =  new DBHelper(this);
        etNome = (EditText) findViewById(R.id.etnome);
        etEnd = (EditText) findViewById(R.id.etencereco);
        etEmp = (EditText) findViewById(R.id.etempresa);

        btInserir = (Button) findViewById(R.id.btInserir);
        btListar = (Button) findViewById(R.id.btlistar);

        btInserir.setOnClickListener(new View.OnClickListener() {
            //Método utilizado para fazer a adição dos dados no banco.
            @Override
            public void onClick(View view) {
                //Se os três campos forem maiores que zero então entra no if.
                if(etNome.getText().length() > 0 && etEnd.getText().length() > 0 && etEmp.getText().length() > 0){
                    //O objeto dh chama o método insert da classe DBHelper e grava os dados passados nos campos da tela.
                    dh.insert(etNome.getText().toString(), etEnd.getText().toString(), etEmp.getText().toString());
                    //Instanciando objeto adb da classe AlertDialog para setar as mensagens e depois mostra-las na tela.
                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("Sucesso");
                    adb.setMessage("Cadastro Realizado");
                    adb.show();

                    //Depois de inserir os dados limpa os campos para um novo preenchimento.
                    etNome.setText("");
                    etEnd.setText("");
                    etEmp.setText("");
                }else{
                    dh.insert(etNome.getText().toString(), etEnd.getText().toString(), etEmp.getText().toString());
                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("Erro");
                    adb.setMessage("Todos os Campos devem ser preenchidos");
                    adb.show();

                    etNome.setText("");
                    etEnd.setText("");
                    etEmp.setText("");
                }
            }
        });

        btListar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Criando uma lista de contatos recebendo o método queryGetAll do atributo da classe DBHelper através do atributo dh.
                List<Contato> contatos = dh.queryGetAll();
                if(contatos == null){
                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("Mensagem");
                    adb.setMessage("Não há registros cadastrados");
                    adb.show();

                    etNome.setText("");
                    etEnd.setText("");
                    etEmp.setText("");
                    return;
                }
                //for para mostrar a lista de contatos na tela.
                for (int i=0; i < contatos.size(); i++){
                    Contato contato = (Contato) contatos.get(i);
                    AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("Registro " + i);
                    adb.setMessage("Nome: " + contato.getNome()+"\nEndereco: " + contato.getEndereco()+"\nEmpresa: "+ contato.getEmpresa());
                    adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int i) {
                            //Fecha a janela e vai para o próximo
                            dialog.dismiss();
                        }
                    });
                    adb.show();
                }
            }
        });
    }


}
